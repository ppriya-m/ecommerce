const app = document.getElementById('app');
app.innerHTML = '<h1>Welcome to the E-commerce App</h1>';
