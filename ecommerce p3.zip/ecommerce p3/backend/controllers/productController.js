exports.getProducts = (req, res) => {
    res.json({ message: "List of products" });
};